import React from "react";
import { createRoot } from "react-dom/client";
import ChatShell from "./features/chat/ChatShell";
import "./styles.css";

createRoot(document.getElementById("root")!).render(<React.StrictMode><ChatShell /></React.StrictMode>);
